<?php $__env->startSection('content'); ?>
<section class="content">
   <div class="card">

        <div class="row justify-content-center mt-5">
            <div class="col-md-12">
                <div class="card-header bg-transparent mb-0">
                    <h5 class="text-center">
                      <span class="font-weight-bold text-primary">
                        Scan
                      </span>
                    </h5>
                </div>
                <div class="card-body">
                    <video id="preview" width="100%" height="500"></video>
                     <form action="<?php echo e(Route('result')); ?>">
                      <div class="d-flex justify-content-center">
                         <div class="p-2 bd-highlight">
                    <div class="form-group">
                        <input type="text" class="form-control" name="q" id=q>
                    </div>
                  </div>
                   <div class="p-2 bd-highlight">
                    <div class="form-group">
                          <button type="submit" class="btn btn-login btn-outline-success">Cari</button>
                      </div>
                    </div>
                      </div>

                  </form>
                 </div>
            </div>
        </div>
     </div>
   </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script   type="text/javascript" src="<?php echo e(asset('js/instascan.min.js')); ?>"></script>
   <script>

      let scanner = new Instascan.Scanner({ video: document.getElementById('preview') });
      scanner.addListener('scan', function (content) {
        $('#q').val(content);
        alert('success');
      });
      Instascan.Camera.getCameras().then(function (cameras) {
        if (cameras.length > 0) {
          scanner.start(cameras[0]);
        } else {
          console.error('No cameras found.');
        }
      }).catch(function (e) {
        console.error(e);
      });

   </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\inventory\resources\views/scan/index.blade.php ENDPATH**/ ?>