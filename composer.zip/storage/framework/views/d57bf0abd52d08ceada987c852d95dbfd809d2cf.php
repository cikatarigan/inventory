<?php $__env->startSection('content'); ?>

<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard</h1>
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li class="breadcrumb-item"><a href="#">Home</a></li>
               <li class="breadcrumb-item active">Dashboard</li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<section class="content">
<div class="row">
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box">
      <span class="info-box-icon bg-info elevation-1"><i class="fas fa-cog"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Goods</span>
        <span class="info-box-number">
          <?php echo e($goods); ?>

        </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>


  <!-- fix for small devices only -->
  <div class="clearfix hidden-md-up"></div>

  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box mb-3">
      <span class="info-box-icon bg-success elevation-1"><i class="fas fa-shopping-cart"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Samples</span>
        <span class="info-box-number"><?php echo e($sample); ?></span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  <!-- /.col -->
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box mb-3">
      <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-users"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Member</span>
        <span class="info-box-number"><?php echo e($users); ?></span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  <!-- /.col -->
</div>

<div class="row">
 <div class="col-md-8">
    <div class="card">
      <div class="card-header border-transparent">
        <h3 class="card-title">Expired Goods</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->

      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table m-0">
            <thead>
            <tr>
              <th>Nama Barang</th>
              <th>Lokasi</th>
              <th>Spesifik Lokasi</th>
              <th>Date Expired</th>
              <th>Jumlah Barang</th>
              <th>Buang Barang</th>
            </tr>
            </thead>
            <tbody>
            <?php if($expired->isNotEmpty()): ?>
            <?php $__currentLoopData = $expired; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($item->good->name); ?></td>
            <td><?php echo e($item->location_shelf->name_shelf); ?></td>
            <td><?php echo e($item->location_shelf->location->name); ?></td>
            <td><?php echo e($item->date_expired); ?></td>
            <td><?php echo e($item->amount - $item->stock_use); ?></td>
            <td> <a href="#"  data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->good->name); ?>" class="btnDelete text-right btn btn-danger"><i class="fas fa-trash"></i> Buang</a></td></td>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php else: ?>
            </tr>
             <tr>
              <td colspan="5">Tidak Ada Data</td>
             </tr>
             <?php endif; ?>
            </tbody>
          </table>
        </div>
        <!-- /.table-responsive -->
      </div>
    </div>
 </div>
 <div class="col-md-4">
  <div class="card">
      <div class="card-header">
        <h3 class="card-title">Barang Di Pinjam</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body p-0">
        <ul class="products-list product-list-in-card pl-2 pr-2">
          <?php $__currentLoopData = $borrow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="item">
            <div class="product-img">
              <?php $__currentLoopData = $item->good->good_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->first): ?>
              <img src="<?php echo e(Storage::url($get->image->path)); ?>" alt="Product Image" class="img-size-50">
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="product-info">
              <a href="javascript:void(0)" class="product-title"><?php echo e($item->good->name); ?>

                <span class="badge bg-danger"><?php echo e($item->user->name); ?></span>
                <span class="badge badge-warning float-right"><?php echo e($item->amount); ?></span></a>
              <span class="product-description">
                <?php echo e($item->description); ?>

              </span>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <!-- /.card-body -->
      <div class="card-footer text-center">
        <a href="<?php echo e(route('borrow.index')); ?>" class="uppercase">View All Borrow</a>
      </div>
      <!-- /.card-footer -->
    </div>
 </div>
</div>
</section>
<?php else: ?>
<section class="content">
  <div class="row">
   <div class="col-md-8">
    <div class="card">
      <div class="card-header border-transparent">
        <h3 class="card-title">Barang Di berikan</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table m-0">
            <thead>
            <tr>
              <th>Nama Barang</th>
               <th>gambar</th>
              <th>Jumlah</th>
              <th>Kapan Di berikan</th>
            </tr>
            </thead>
            <tbody>
            <tr>
             <?php $__currentLoopData = $allotment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($item->good->name); ?></td>
              <?php $__currentLoopData = $item->good->good_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->first): ?>
            <td>   <img src="<?php echo e(Storage::url($get->image->path)); ?>" alt="Product Image" class="img-size-50"></td>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <td><?php echo e($item->amount); ?></td>
              <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>

            </tbody>
          </table>
        </div>
        <!-- /.table-responsive -->
      </div>

    </div>
 </div>
 <div class="col-md-4">
  <div class="card">
      <div class="card-header">
        <h3 class="card-title">Barang Di Pinjam</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body p-0">
        <ul class="products-list product-list-in-card pl-2 pr-2">
          <?php $__currentLoopData = $borrow_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="item">
            <div class="product-img">
              <?php $__currentLoopData = $item->good->good_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->first): ?>
              <img src="<?php echo e(Storage::url($get->image->path)); ?>" alt="Product Image" class="img-size-50">
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="product-info">
              <a href="javascript:void(0)" class="product-title"><?php echo e($item->good->name); ?>

                <span class="badge badge-warning float-right">Amount :<?php echo e($item->amount); ?></span></a>
              <span class="product-description">
                <?php echo e($item->description); ?>

              </span>
            </div>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <!-- /.card-body -->
      <div class="card-footer text-center">
        <a href="<?php echo e(route('borrow.index')); ?>" class="uppercase">View All Borrow</a>
      </div>
      <!-- /.card-footer -->
    </div>
 </div>
</div>
  </section>


<?php endif; ?>


<div class="modal" tabindex="-1" role="dialog" id="ExpiredModal">
  <div class="modal-dialog">
    <div class="modal-content">
        <form action="#" method="post" id="FormExpired">
        <input type="hidden" id="id_expired" name="id" value="">
      <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p id="del-success"></p>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Ya</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
jQuery(document).ready(function($) {

    $('.btnDelete').click(function () {
            var id = $(this).data('id');
            var name = $(this).data('name');
           $('#FormExpired .modal-title').text("Konfirmasi");
           $('#FormExpired .help-block').empty();
           $('#FormExpired #id_expired').val(id);
           $('#FormExpired')[0].reset();
           $('#FormExpired #del-success').html("Apakah Anda yakin ingin menghapus <b>"+name+"</b> ini ?");
             url= 'expired/' + id;
             console.log(url);
        $('#ExpiredModal').modal('show');
    });
    $('#FormExpired').submit(function (event) {
         event.preventDefault();
         var $this = $(this);
         var form = $('#FormExpired');

         $('#FormExpired div.form-group').removeClass('has-error');
         $('#FormExpired .help-block').empty();

         var data = form.serialize();
         console.log(data);
         $.ajax({
             url: url,
             type: 'POST',
             data: data,
             cache: false,
             success: function (data) {
                 console.log(data)
                 if (data.success) {
                     toastr.success(data.message);
                     $('#ExpiredModal').modal('hide');
                     $("#FormExpired")[0].reset();
                       location.reload();
                 } else {
                     toastr.error(data.message);
                 }
             },
         })
     });


 });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\inventory\resources\views/home/index.blade.php ENDPATH**/ ?>