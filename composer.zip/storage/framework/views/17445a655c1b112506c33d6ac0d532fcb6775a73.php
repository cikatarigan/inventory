<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title><?php echo e(config('app.name')); ?> | Log in Admin</title>
      <!-- Tell the browser to be responsive to screen width -->
      
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- CSRF Token -->
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <!-- CSS -->
      <link rel="stylesheet" type="text/css" href="<?php echo e(mix('css/app.css')); ?>">
   </head>
   <body class="hold-transition login-page">
      <div class="login-box">
         <div class="login-logo">
            <a href="<?php echo e(config('app.url')); ?>"> <b><?php echo e(config('app.name')); ?></b> admin</a>
         </div>
         <!-- /.login-logo -->
         <div class="card">
            <div class="card-body login-card-body">
               <p class="login-box-msg">Sign in to start your session</p>
               <form class="form-horizontal" method="POST" action="<?php echo e(route('auth.login.submit')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="input-group mb-3 has-feedback">
                     <input id="username" type="username" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required  autofocus placeholder="Email or username">
                      <div class="input-group-append">
                        <div class="input-group-text">
                           <span class="fas fa-user"></span>
                        </div>
                     </div>
                     <?php if($errors->has('username')): ?>
                     <span class="invalid-feedback">
                     <strong><?php echo e($errors->first('username')); ?></strong>
                     </span>
                     <?php endif; ?>
                  </div>
                  <div class="input-group mb-3  has-feedback">
                     <input id="password" placeholder="password" type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" name="password" required>
                     <div class="input-group-append">
                        <div class="input-group-text">
                           <span class="fas fa-lock"></span>
                        </div>
                     </div>
                     <?php if($errors->has('password')): ?>
                     <span class="invalid-feedback">
                     <strong><?php echo e($errors->first('password')); ?></strong>
                     </span>
                     <?php endif; ?>
                  </div>
                  
                  <div class="row">
                     <div class="col-8">
                        <div class="icheck-primary">
                           <input type="checkbox" id="remember">
                           <label for="remember">
                           Remember Me
                           </label>
                        </div>
                     </div>
                     <!-- /.col -->
                     <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                     </div>
                     <!-- /.col -->
                  </div>
               </form>
            </div>
            <!-- /.login-card-body -->
         </div>
      </div>
      <!-- JS -->
      <script src="<?php echo e(mix('js/app.js')); ?>"></script>
      
   </body>
</html><?php /**PATH D:\xampp\htdocs\inventory\resources\views/auth/login.blade.php ENDPATH**/ ?>